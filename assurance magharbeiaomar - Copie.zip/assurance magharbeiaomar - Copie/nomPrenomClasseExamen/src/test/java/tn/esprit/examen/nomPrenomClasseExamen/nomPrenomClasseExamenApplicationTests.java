package tn.esprit.examen.nomPrenomClasseExamen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class nomPrenomClasseExamenApplicationTests {

    @Test
    void contextLoads() {
    }

}
