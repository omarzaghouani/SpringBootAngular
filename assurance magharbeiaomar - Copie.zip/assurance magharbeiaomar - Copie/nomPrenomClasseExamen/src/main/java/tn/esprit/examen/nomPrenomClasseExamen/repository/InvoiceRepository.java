package tn.esprit.examen.nomPrenomClasseExamen.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tn.esprit.examen.nomPrenomClasseExamen.Entiti.Invoice;

public interface InvoiceRepository extends JpaRepository<Invoice, Long> {
}
