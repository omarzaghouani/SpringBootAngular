package tn.esprit.examen.nomPrenomClasseExamen.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tn.esprit.examen.nomPrenomClasseExamen.Entiti.ContractDocument;

public interface ContractDocumentRepository extends JpaRepository<ContractDocument, Long> {
}
