package tn.esprit.examen.nomPrenomClasseExamen.service;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import tn.esprit.examen.nomPrenomClasseExamen.Entiti.Contract;
import tn.esprit.examen.nomPrenomClasseExamen.Entiti.ContractStatistics;
import tn.esprit.examen.nomPrenomClasseExamen.Entiti.ContractStatus;
import tn.esprit.examen.nomPrenomClasseExamen.repository.ContractRepository;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

@AllArgsConstructor
@Service
public class ContractService implements IContractService {
    private final ContractRepository contractRepository;

    // You should either inject this directory from the application.properties or set it as a constant
    private static final String CONTRACTS_DIRECTORY = "/path/to/contracts/";

    @Override
    public Contract addContract(Contract contract) {
        return contractRepository.save(contract);
    }

    @Override
    public List<Contract> getAllContracts() {
        return contractRepository.findAll();
    }

    @Override
    public Optional<Contract> getContractById(Long id) {
        return contractRepository.findById(id);
    }

    @Override
    public Contract updateContract(Long id, Contract updatedContract) {
        return contractRepository.findById(id).map(contract -> {
            contract.setNumber(updatedContract.getNumber());
            contract.setStartDate(updatedContract.getStartDate());
            contract.setEndDate(updatedContract.getEndDate());
            contract.setStatus(updatedContract.getStatus());
            return contractRepository.save(contract);
        }).orElseThrow(() -> new RuntimeException("Contract not found with ID: " + id));
    }

    @Override
    public void deleteContract(Long id) {
        contractRepository.deleteById(id);
    }

    @Override
    public List<Contract> searchContracts(Date startDate, Date endDate, String status, String number) {
        return contractRepository.findByAdvancedSearch(startDate, endDate, status, number);
    }

    @Override
    public byte[] getContractFile(String number) {
        try {
            // Define the file path based on the contract number
            Path filePath = Paths.get(CONTRACTS_DIRECTORY + "contrat_" + number + ".pdf");

            // Read the file content into a byte array
            return Files.readAllBytes(filePath);
        } catch (IOException e) {
            // Handle the exception (e.g., log it, return an empty byte array, etc.)
            e.printStackTrace();
            return new byte[0];  // or return null if preferred
        }
    }

    @Override
    public long countContractsByStatus(ContractStatus status) {
        return contractRepository.countByStatus(String.valueOf(status));

    }




    @Override
    public long countByStatus(String status) {
        return contractRepository.countByStatus(status);
    }
}



