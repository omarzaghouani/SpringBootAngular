package tn.esprit.examen.nomPrenomClasseExamen.controller;

import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import tn.esprit.examen.nomPrenomClasseExamen.Entiti.Contract;
import tn.esprit.examen.nomPrenomClasseExamen.Entiti.ContractStatistics;
import tn.esprit.examen.nomPrenomClasseExamen.Entiti.ContractStatus;
import tn.esprit.examen.nomPrenomClasseExamen.service.IContractService;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/contrats")
public class ContractController {

    @Autowired
    private IContractService contractService;

    @PostMapping("/add")
    public ResponseEntity<Contract> createContract(@RequestBody Contract contract) {
        Contract createdContract = contractService.addContract(contract);
        return new ResponseEntity<>(createdContract, HttpStatus.CREATED);
    }

    @GetMapping("/all")
    public ResponseEntity<List<Contract>> getAllContrats() {
        List<Contract> contrats = contractService.getAllContracts();
        return ResponseEntity.ok().body(contrats);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Contract> getContractById(@PathVariable Long id) {
        Optional<Contract> contract = contractService.getContractById(id);
        return contract.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Contract> updateContract(@PathVariable Long id, @RequestBody Contract contract) {
        try {
            Contract updatedContract = contractService.updateContract(id, contract);
            return new ResponseEntity<>(updatedContract, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteContract(@PathVariable Long id) {
        contractService.deleteContract(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/search")
    public ResponseEntity<List<Contract>> searchContracts(
            @RequestParam(required = false) Date startDate,
            @RequestParam(required = false) Date endDate,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String number) {

        List<Contract> contracts = contractService.searchContracts(startDate, endDate, status, number);
        return contracts.isEmpty() ?
                new ResponseEntity<>(HttpStatus.NO_CONTENT) :
                new ResponseEntity<>(contracts, HttpStatus.OK);
    }

    @GetMapping("/download/{number}")
    public ResponseEntity<ByteArrayResource> downloadContract(@PathVariable String number) {
        byte[] fileContent = contractService.getContractFile(number);
        ByteArrayResource resource = new ByteArrayResource(fileContent);

        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF) // Adjust if using another file type
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=contrat_" + number + ".pdf")
                .body(resource);
    }
    @GetMapping("/count/{status}")
    public long getContractCountByStatus(@PathVariable ContractStatus status) {
        return contractService.countContractsByStatus(status);
    }
}
