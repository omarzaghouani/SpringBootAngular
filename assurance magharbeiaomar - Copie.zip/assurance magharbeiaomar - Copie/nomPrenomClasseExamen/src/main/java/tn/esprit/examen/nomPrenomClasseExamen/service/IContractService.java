package tn.esprit.examen.nomPrenomClasseExamen.service;


import tn.esprit.examen.nomPrenomClasseExamen.Entiti.Contract;
import tn.esprit.examen.nomPrenomClasseExamen.Entiti.ContractStatus;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface IContractService {
    // Create or update contract
    Contract addContract(Contract contract);

    // Get all contracts
    List<Contract> getAllContracts();

    // Get contract by ID
    Optional<Contract> getContractById(Long id);
    Contract updateContract(Long id, Contract updatedContract);
    // Delete contract
    void deleteContract(Long id);
    List<Contract> searchContracts(Date startDate, Date endDate, String status, String number);


    byte[] getContractFile(String number);
    long countContractsByStatus(ContractStatus status);

    long countByStatus(String status);
}
