package tn.esprit.examen.nomPrenomClasseExamen.Entiti;

public enum InvoiceStatus {
    PENDING,
    PAID,
    CANCELLED
}
