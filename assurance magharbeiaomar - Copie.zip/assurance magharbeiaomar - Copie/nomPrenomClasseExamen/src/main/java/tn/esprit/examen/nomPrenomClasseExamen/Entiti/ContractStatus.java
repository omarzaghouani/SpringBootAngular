package tn.esprit.examen.nomPrenomClasseExamen.Entiti;

public enum ContractStatus {
    ONGOING,
    COMPLETED,
    CANCELLED
}
